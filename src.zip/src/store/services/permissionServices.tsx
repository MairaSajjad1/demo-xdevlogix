import { addTokenToRequest } from "@/lib/utils";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const permissionService = createApi({
  reducerPath: "permissionService",
  tagTypes: ["permission"],
  baseQuery: fetchBaseQuery({
    baseUrl:
      process.env.NEXT_PUBLIC_API_BASE_URL ||
      "https://demo.onlineorder.dev-logix.com/api",

    prepareHeaders: async (headers, { getState }) => {
      headers.set("Accept", "application/json");
      await addTokenToRequest(headers, { getState });
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getPermissions: builder.query({
      query: ({ buisnessId, roleId, perPage }) => ({
        url: `/permission?business_id=${buisnessId}&role_id=6&per_page=${perPage}`,
        method: "GET",
      }),
      providesTags: ["permission"],
    }),

    getSinglePermission: builder.query({
      query: ({ buisnessId, roleId, permissionId }) => ({
        url: `/get-assign-permission?business_id=${buisnessId}&role_id=${roleId}&permission_id=${permissionId}`,
        method: "GET",
      }),
      providesTags: ["permission"],
    }),

    updatePermission: builder.mutation({
      query: ({ roleId, permissionData }) => ({
        url: `/api/permission/edit/6`,
        method: "POST",
        body: permissionData,
      }),
      invalidatesTags: ["permission"],
    }),
  }),
});

export const {
  useGetPermissionsQuery,
  useGetSinglePermissionQuery,
  useUpdatePermissionMutation,
} = permissionService;

export default permissionService;
