import Units from "@/views/units";

const page = () => {
  return <Units />;
};

export default page;
