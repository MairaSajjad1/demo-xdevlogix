import Brands from "@/views/brands";

const page = () => {
  return <Brands />;
};

export default page;
