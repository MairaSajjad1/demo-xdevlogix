import Purchases from "@/views/purchases";

const page = () => {
  return <Purchases />;
};

export default page;
