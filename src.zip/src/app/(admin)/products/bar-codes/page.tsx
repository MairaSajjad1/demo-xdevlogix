import Barcodes from "@/views/bar-codes";

const page = () => {
  return <Barcodes />;
};

export default page;
