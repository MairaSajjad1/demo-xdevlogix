import ProductsList from "@/views/products-list";

const page = () => {
  return <ProductsList />;
};

export default page;
