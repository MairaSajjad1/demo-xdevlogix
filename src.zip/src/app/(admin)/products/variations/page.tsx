import Variations from "@/views/variations";

const page = () => {
  return <Variations />;
};

export default page;
