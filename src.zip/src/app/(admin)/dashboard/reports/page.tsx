import Home from "@/views/home";

const page = () => {
  return <Home />;
};

export default page;