import Taxrates from "@/views/taxrates";

const page = () => {
  return <Taxrates />;
};

export default page;
