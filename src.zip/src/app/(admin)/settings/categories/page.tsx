import Categories from "@/views/categories";

const page = () => {
  return <Categories />;
};

export default page;
