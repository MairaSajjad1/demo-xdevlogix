import Buisnesses from "@/views/buisnesses";

const page = () => {
  return <Buisnesses />;
};

export default page;
