import Locations from "@/views/locations";

const page = () => {
  return <Locations />;
};

export default page;
