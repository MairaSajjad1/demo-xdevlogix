import Orders from "@/views/orders";

const page = () => {
  return <Orders />;
};

export default page;
