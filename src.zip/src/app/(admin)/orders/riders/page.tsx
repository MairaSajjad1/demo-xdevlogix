import Riders from "@/views/riders";

const page = () => {
  return <Riders />;
};

export default page;
