import Suppliers from "@/views/suppliers";

const page = () => {
  return <Suppliers />;
};

export default page;
