import OrdersList from "@/views/orders-list";

const page = () => {
  return <OrdersList />;
};

export default page;
