import Roles from "@/views/roles";

const page = () => {
  return <Roles />;
};

export default page;
