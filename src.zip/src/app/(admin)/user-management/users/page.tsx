import Users from "@/views/users";

const page = () => {
  return <Users />;
};

export default page;
