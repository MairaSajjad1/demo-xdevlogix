import TypeOfService from "@/views/typeofservices";

const page = () => {
  return <TypeOfService />;
};

export default page;
