"use client"
import { FC, useCallback, useEffect, useMemo, useState } from "react";
import Table from "@/components/table";
import { DataTableColumnHeader } from "@/components/table/data-table-column-header";
import { DataTableRowActions } from "@/components/table/data-table-row-actions";
import DeleteModal from "@/components/modal/delete-modal";
import { ColumnDef } from "@tanstack/react-table";
import { useSession } from "next-auth/react";
import Modal from "@/components/modal";
import { BiLoaderAlt as Loader } from "react-icons/bi";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { RootState } from "@/store";
import { useGetPermissionsQuery } from "@/store/services/permissionServices";
import { useSearchParams } from 'next/navigation'
import toast from "react-hot-toast";
import PermissionForm from "./PermissionForm";

interface PermissionsProps{
  roleId:string;
}

export interface Permission{
  can_create: boolean;
      can_view: boolean;
      can_delete: boolean;
      can_update: boolean;
      business_id: number;

}

const Permissions:FC<PermissionsProps> = ({roleId}) => {
  // const { roleId } = router.query;
  const { data: session } = useSession();

  const {
    data: permissionList,
    isLoading: permissionLoading,
    isFetching: permissionFetching,
  } = useGetPermissionsQuery({
    buisnessId: session?.user?.business_id,
    roleId,
    perPage: -1,
  });

  const [open, setOpen] = useState<boolean>(false);
  const [openDelete, setOpenDelete] = useState<boolean>(false);

  const [selectedPermission, setSelectedPermission] = useState<Permission | null>(null);

  console.log(permissionList)

  // interface Permissions {
  //   // id: number;
  //   name: string;
  //   business_id: number;
  // }
  const columns: ColumnDef< Permission | null>[] = useMemo(
    () => [
      {
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Name" />
        ),
        cell: ({ row }) => (
          <>
            {row?.original ? (
              <div>{row.getValue("name")}</div>
            ) : (
              <Skeleton className="w-40 h-4 bg-[#F5f5f5]" />
            )}
          </>
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        id: "actions",
        cell: ({ row }) => (
          <DataTableRowActions
            deleteAction={handleDelete}
            editAction={handleEdit}
            row={row}
          />
        ),
      },
    ],
    []
  );
 
  const handleEdit = (data: Permission | null) => {
    setSelectedPermission(data);
    toggleModal();
  };


  const loadingData = Array.from({ length: 10 }, () => null);

  const toggleModal = useCallback(() => {
    setOpen((open) => !open);
  }, [open]);

  const toggleDeleteModal = useCallback(() => {
    setOpenDelete((open) => !open);
  }, [open]);
  
  const confirmDelete = () => {
    toast.error("Delete APi is not implemented Yet");
    toggleDeleteModal();
  };

  const handleDelete = (data: Permission | null) => {
    setSelectedPermission(data);
    toggleDeleteModal();
  };

  return (
    <>
    <div className="bg-[#FFFFFF] p-2 rounded-md overflow-hidden space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-semibold text-xl text-[#4741E1]">Permissions</h1>
          <p className="font-medium text-sm">A list of all the Permissions.</p>
        </div>
      </div>
      <Separator />
      <Table 
  // @ts-expect-error
         columns={columns}
        data=
        {permissionLoading || permissionFetching ? loadingData : permissionList?.data || []
        }
        filterKey="name"
      />
    </div>
   {/* <Modal
        title={selectedPermission ? "Update Permissions" : "Add New Permission"}
        open={open}
        setOpen={toggleModal}
        body={<PermissionForm setOpen={toggleModal} data={selectedPermission} />}
      /> */}

        {selectedPermission && (
          <Modal
            title="Update Permissions"
            open={open}
            setOpen={toggleModal}
            body={<PermissionForm setOpen={toggleModal} data={selectedPermission} />}
          />
        )}

      <DeleteModal
        open={openDelete}
        setOpen={toggleDeleteModal}
        loading={false}
        confirmDelete={confirmDelete}
      />
   </>
  );
  
};

export default Permissions;
