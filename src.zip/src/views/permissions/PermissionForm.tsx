import { FC, useEffect } from "react";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useSession } from "next-auth/react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BiLoaderAlt as Loader } from "react-icons/bi";
import toast from "react-hot-toast";
import { Checkbox } from "@/components/ui/checkbox"
import { useUpdatePermissionMutation } from "@/store/services/permissionServices";

const formSchema = z.object({
  can_create: z.boolean(),
  can_view: z.boolean(),
  can_delete: z.boolean(),
  can_update: z.boolean(),
  bussines_id: z.coerce.number(),
});

interface PermissionFormProps {
  setOpen: () => void;
  data?: {
    can_create: boolean;
    can_view: boolean;
    can_delete: boolean;
    can_update: boolean;
    business_id: number;
  } | null;
}
  

const PermissionForm: FC<PermissionFormProps> = ({ setOpen, data }) => {
    const { data: session } = useSession();
    
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      can_create: data?.can_create ?? false,
      can_view: data?.can_view ?? false,
      can_delete: data?.can_delete ?? false,
      can_update: data?.can_update ?? false,
      // business_id: session?.user?.business_id,
      bussines_id: data?.business_id || Number(session?.user?.business_id || 0),
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log("hamza",permissionData);
    
    data
      ? toast.error("Update API is not implemented Yet")
      : update({ permissionData: values }); 
  }



  const [update, updateResponse] = useUpdatePermissionMutation();
  console.log(updateResponse);
  
  const {
    isLoading: updateLoading,
    isError: updateError,
    isSuccess: updateSuccess,
  } = updateResponse;
//   const [create, createResponse] = useCreateTypeOfServiceMutation();
//   const {
//     isLoading: createLoading,
//     isError: createError,
//     isSuccess: createSuccess,
//   } = createResponse;



  useEffect(() => {
    if (updateError) {
      toast.error("Something went Wrong.");
    }
    if (updateSuccess) {
      toast.success("Permission Updated Successfully.");
      setOpen();
    }
  }, [updateError, updateSuccess]);

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-2">
       
      <FormField
  control={form.control}
  name="can_create"
  render={({ field }) => (
    <FormItem className="flex items-center justify-end space-x-2 rounded-md border p-2">
      <FormControl>
        <Input
          type="checkbox"
          id="can_create"
          checked={field.value}
          onChange={field.onChange}
        />
      </FormControl>
      <div className="space-y-1 leading-none">
        <FormLabel>can_create</FormLabel>
      </div>
    </FormItem>
  )}
/>
         {/* <FormField
          control={form.control}
          name="can_view"
          render={({ field }) => (
            <FormItem>
              <FormLabel>can_view</FormLabel>
              <FormControl>
              <Input type="checkbox" {...field} />              
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        /> */}
  <FormField
  control={form.control}
  name="can_view"
  render={({ field }) => (
    <FormItem className="flex items-center justify-end space-x-2 rounded-md border p-2">
      <FormControl>
        <Input
          type="checkbox"
          id="can_view"
          checked={field.value}
          onChange={field.onChange}
        />
      </FormControl>
      <div className="space-y-1 leading-none">
        <FormLabel>can_view</FormLabel>
      </div>
    </FormItem>
  )}
/>


<FormField
  control={form.control}
  name="can_delete"
  render={({ field }) => (
    <FormItem className="flex items-center justify-end space-x-2 rounded-md border p-2">
      <FormControl>
        <Input
          type="checkbox"
          id="can_delete"
          checked={field.value}
          onChange={field.onChange}
        />
      </FormControl>
      <div className="space-y-1 leading-none">
        <FormLabel>can_delete</FormLabel>
      </div>
    </FormItem>
  )}
/>
<FormField
  control={form.control}
  name="can_update"
  render={({ field }) => (
    <FormItem className="flex items-center justify-end space-x-2 rounded-md border p-2">
      <FormControl>
        <Input
          type="checkbox"
          id="can_update"
          checked={field.value}
          onChange={field.onChange}
        />
      </FormControl>
      <div className="space-y-1 leading-none">
        <FormLabel>can_update</FormLabel>
      </div>
    </FormItem>
  )}
/>
        {/* <Button disabled={createLoading} className="w-full" type="submit">
          {createLoading && <Loader className="mr-2 h-4 w-4 animate-spin" />}
          {data ? "Update" : "Add"}
        </Button> */}
        <Button
  disabled={updateLoading}
  className="w-full"
  type="submit"
>
  {updateLoading ? (
    <Loader className="mr-2 h-4 w-4 animate-spin" />
  ) : (
    "Update"
  )}
</Button>

      </form>
    </Form>
  );
};

export default PermissionForm;
